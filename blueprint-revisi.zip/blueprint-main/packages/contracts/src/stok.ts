import { z } from 'zod';

export const stokMasukSchema = z.object({
  sku: z.string().min(3),
  qty: z.number().int().positive(),
  catatan: z.string().optional(),
});
export type StokMasuk = z.infer<typeof stokMasukSchema>;
