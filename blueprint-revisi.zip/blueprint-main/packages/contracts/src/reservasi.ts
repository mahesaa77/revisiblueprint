import { z } from 'zod';

export const konfigurasiDpSchema = z.object({
  tipe: z.enum(['PERSEN', 'NOMINAL']),
  nilai: z.number().int().positive(),
  holdJam: z.number().int().min(24).max(48),
});
export type KonfigurasiDp = z.infer<typeof konfigurasiDpSchema>;

export const buatReservasiSchema = z.object({
  sku: z.string().min(3),
  qty: z.number().int().positive(),
  namaPelanggan: z.string().trim().min(2),
  kontak: z.string().trim().min(5),
});
export type BuatReservasi = z.infer<typeof buatReservasiSchema>;

export const statusReservasiSchema = z.enum(['MENUNGGU_DP', 'DP_DIBAYAR', 'LUNAS', 'DIBATALKAN', 'KEDALUWARSA']);
export type StatusReservasi = z.infer<typeof statusReservasiSchema>;
