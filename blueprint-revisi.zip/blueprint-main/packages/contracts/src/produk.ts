import { z } from 'zod';

/** Varian = satu SKU (kombinasi ukuran + warna). Harga dalam rupiah (integer). */
export const varianSchema = z.object({
  sku: z.string().min(3),
  ukuran: z.string(),
  warna: z.string(),
  stokTersedia: z.number().int().nonnegative(),
});
export type Varian = z.infer<typeof varianSchema>;

export const produkSchema = z.object({
  id: z.string(),
  nama: z.string(),
  kategori: z.string(),
  deskripsi: z.string(),
  harga: z.number().int().nonnegative(),
  varian: z.array(varianSchema),
});
export type Produk = z.infer<typeof produkSchema>;

export const queryProdukSchema = z.object({
  kategori: z.string().trim().min(1).optional(),
  search: z.string().trim().min(1).optional(),
  page: z.coerce.number().int().positive().default(1),
  pageSize: z.coerce.number().int().positive().max(50).default(12),
});
export type QueryProduk = z.infer<typeof queryProdukSchema>;

export const detailProdukSchema = z.object({
  produk: produkSchema,
  varianDipilih: varianSchema,
  qrPayload: z.string(),
  terkait: z.array(produkSchema.omit({ varian: true, deskripsi: true })),
});
export type DetailProduk = z.infer<typeof detailProdukSchema>;
