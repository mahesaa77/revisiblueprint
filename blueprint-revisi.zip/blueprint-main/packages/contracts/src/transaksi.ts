import { z } from 'zod';

export const metodeBayarSchema = z.enum(['TUNAI', 'QRIS', 'KARTU', 'EWALLET']);
export type MetodeBayar = z.infer<typeof metodeBayarSchema>;

export const itemTransaksiSchema = z.object({
  sku: z.string().min(3),
  qty: z.number().int().positive(),
});

/** idempotencyKey dibuat di perangkat kasir, sehingga sinkron ulang tidak menggandakan transaksi. */
export const buatTransaksiSchema = z.object({
  idempotencyKey: z.string().min(8),
  items: z.array(itemTransaksiSchema).min(1),
  diskon: z.number().int().nonnegative().default(0),
  pembayaran: z
    .array(z.object({ metode: metodeBayarSchema, jumlah: z.number().int().positive() }))
    .min(1),
});
export type BuatTransaksi = z.infer<typeof buatTransaksiSchema>;

export const batchSyncSchema = z.object({
  transaksi: z.array(buatTransaksiSchema).min(1).max(200),
});
export type BatchSync = z.infer<typeof batchSyncSchema>;

export const returSchema = z.object({
  items: z.array(itemTransaksiSchema).min(1),
});
export type Retur = z.infer<typeof returSchema>;
