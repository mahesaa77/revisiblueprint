# Referensi API (`/api/v1`)

Semua body JSON divalidasi dengan skema Zod di `packages/contracts`. Error: `{ statusCode, code, message, details? }`.

| Modul | Method | Endpoint | Keterangan |
|---|---|---|---|
| Platform | GET | `/health` | Status layanan |
| M1 | GET | `/produk?kategori=&search=&page=&pageSize=` | Katalog dan pencarian |
| M1 | GET | `/produk/{sku}` | Detail via scan; stok real-time, `qrPayload`, produk terkait |
| M2 | POST | `/transaksi` | Buat transaksi. `201` baru, `200` bila `idempotencyKey` sudah ada |
| M2 | POST | `/transaksi/batch-sync` | Sinkron offline; hasil per item `DISIMPAN` / `DUPLIKAT` / `DITOLAK` |
| M2 | GET | `/transaksi/{id}` | Detail transaksi |
| M2 | POST | `/transaksi/{id}/retur` | Retur; stok kembali, jurnal balik otomatis |
| M3 | GET/PUT | `/admin/konfigurasi-dp` | Skema DP `{tipe: PERSEN\|NOMINAL, nilai, holdJam 24–48}` |
| M3 | POST | `/reservasi` | Buat reservasi dan hold stok |
| M3 | GET | `/reservasi/{id}` | Status (kedaluwarsa dilepas otomatis) |
| M3 | POST | `/reservasi/{id}/bayar-dp` | `MENUNGGU_DP` → `DP_DIBAYAR` |
| M3 | POST | `/reservasi/{id}/lunasi` | `DP_DIBAYAR` → `LUNAS`, hold jadi penjualan |
| M3 | POST | `/reservasi/{id}/batal` | Hanya sebelum DP dibayar |
| M4 | POST | `/stok/masuk` | Stok masuk |
| M4 | GET | `/stok/{sku}/kartu` | Kartu stok |
| M5 | GET | `/laporan/coa` · `/jurnal` · `/neraca-saldo` · `/laba-rugi` · `/buku-besar/{kode}` | Laporan dari jurnal otomatis |

Kode error umum: `VALIDASI_GAGAL` (400), `PEMBAYARAN_KURANG` (400), `SKU_TIDAK_DITEMUKAN` (404),
`STOK_TIDAK_CUKUP` (409), `RETUR_MELEBIHI_PEMBELIAN` (409), `STATUS_TIDAK_VALID` (409).

Belum ada: autentikasi/RBAC, `/auth/login`, `/webhook/payment`, `/produksi`, `/stok/opname`, `/stok/keluar`,
`/laporan/neraca`, `/laporan/arus-kas`.
