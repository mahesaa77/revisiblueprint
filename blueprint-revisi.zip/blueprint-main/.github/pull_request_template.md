## Ringkasan
<!-- Apa yang berubah dan kenapa -->

## Checklist
- [ ] `pnpm typecheck` dan `pnpm test` lulus
- [ ] Test baru untuk perilaku baru
- [ ] Dokumentasi (README/docs) diperbarui bila perlu
- [ ] Commit message mengikuti `<tipe>(<modul>): <deskripsi>`
