import { Test } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module.js';

describe('API (e2e)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication();
    app.setGlobalPrefix('api/v1');
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  const http = () => request(app.getHttpServer());

  it('GET /health mengembalikan status ok', async () => {
    const { body } = await http().get('/api/v1/health').expect(200);
    expect(body.status).toBe('ok');
  });

  it('GET /produk?kategori=kaos memfilter katalog', async () => {
    const { body } = await http().get('/api/v1/produk?kategori=kaos').expect(200);
    expect(body.meta.total).toBe(1);
  });

  it('GET /produk/:sku 404 memakai amplop error', async () => {
    const { body } = await http().get('/api/v1/produk/TIDAK-ADA').expect(404);
    expect(body).toMatchObject({ statusCode: 404, code: 'PRODUK_TIDAK_DITEMUKAN' });
  });

  it('POST /transaksi memvalidasi body dengan Zod', async () => {
    const { body } = await http().post('/api/v1/transaksi').send({ items: [] }).expect(400);
    expect(body.code).toBe('VALIDASI_GAGAL');
  });

  it('alur kasir: transaksi -> idempoten -> laporan seimbang', async () => {
    const payload = {
      idempotencyKey: 'e2e-kunci-0001',
      items: [{ sku: 'KAO-BSC-HTM-S', qty: 1 }],
      pembayaran: [{ metode: 'TUNAI', jumlah: 100000 }],
    };
    await http().post('/api/v1/transaksi').send(payload).expect(201);
    await http().post('/api/v1/transaksi').send(payload).expect(200);
    const { body } = await http().get('/api/v1/laporan/neraca-saldo').expect(200);
    expect(body.seimbang).toBe(true);
    const lr = await http().get('/api/v1/laporan/laba-rugi').expect(200);
    expect(lr.body.labaKotor).toBe(89000 - 38000);
  });

  it('alur reservasi: buat -> bayar DP -> lunasi', async () => {
    const r = await http().post('/api/v1/reservasi').send({ sku: 'ROK-PLS-HTM-ALL', qty: 1, namaPelanggan: 'Budi', kontak: '081200001111' }).expect(201);
    await http().post(`/api/v1/reservasi/${r.body.id}/bayar-dp`).expect(200);
    const l = await http().post(`/api/v1/reservasi/${r.body.id}/lunasi`).expect(200);
    expect(l.body.status).toBe('LUNAS');
  });
});
