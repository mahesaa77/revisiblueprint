import { AkuntansiService } from '../src/modules/akuntansi/application/akuntansi.service.js';
import { InventoriService } from '../src/modules/inventori/application/inventori.service.js';
import { KatalogService } from '../src/modules/katalog/application/katalog.service.js';
import { ProdukMemoryRepository } from '../src/modules/katalog/infrastructure/produk-memory.repository.js';
import { PenjualanService } from '../src/modules/penjualan/application/penjualan.service.js';
import { ReservasiService } from '../src/modules/reservasi/application/reservasi.service.js';
import { InMemoryEventBus } from '../src/platform/messaging/event-bus.js';

/** Merangkai semua service tanpa NestJS, dengan jam yang bisa dimajukan di test. */
export function buatSistem(ppnPersen = 0) {
  let waktu = new Date('2026-11-27T03:00:00.000Z');
  const now = () => new Date(waktu);
  const bus = new InMemoryEventBus();
  const repo = new ProdukMemoryRepository();
  const inventori = new InventoriService(now);
  const katalog = new KatalogService(repo, inventori, 'http://toko.test');
  const akuntansi = new AkuntansiService(now);
  akuntansi.daftarkanHandler(bus);
  const penjualan = new PenjualanService(repo, inventori, bus, ppnPersen, now);
  const reservasi = new ReservasiService(repo, inventori, bus, now);
  return {
    inventori, katalog, akuntansi, penjualan, reservasi,
    majukanJam: (jam: number) => { waktu = new Date(waktu.getTime() + jam * 3_600_000); },
  };
}
