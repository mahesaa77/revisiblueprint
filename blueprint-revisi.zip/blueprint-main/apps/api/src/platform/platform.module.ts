import { Global, Module } from '@nestjs/common';
import { APP_CONFIG, bacaConfig } from './config/app-config.js';
import { EventBus, InMemoryEventBus } from './messaging/event-bus.js';

@Global()
@Module({
  providers: [
    { provide: EventBus, useClass: InMemoryEventBus },
    { provide: APP_CONFIG, useFactory: () => bacaConfig() },
  ],
  exports: [EventBus, APP_CONFIG],
})
export class PlatformModule {}
