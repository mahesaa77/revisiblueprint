import { ArgumentsHost, Catch, ExceptionFilter, HttpException, Logger } from '@nestjs/common';
import type { Response } from 'express';
import type { ErrorResponse } from '@toko/contracts';
import { DomainError } from '../errors.js';

/** Semua error keluar dalam amplop yang sama: { statusCode, code, message, details? }. */
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly logger = new Logger(AllExceptionsFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const res = host.switchToHttp().getResponse<Response>();
    const body = this.petakan(exception);
    if (body.statusCode >= 500) {
      this.logger.error(exception instanceof Error ? (exception.stack ?? exception.message) : String(exception));
    }
    res.status(body.statusCode).json(body);
  }

  private petakan(exception: unknown): ErrorResponse {
    if (exception instanceof DomainError) {
      return {
        statusCode: exception.statusCode,
        code: exception.code,
        message: exception.message,
        ...(exception.details ? { details: exception.details } : {}),
      };
    }
    if (exception instanceof HttpException) {
      return {
        statusCode: exception.getStatus(),
        code: exception.getStatus() === 404 ? 'TIDAK_DITEMUKAN' : 'HTTP_ERROR',
        message: exception.message,
      };
    }
    return { statusCode: 500, code: 'KESALAHAN_INTERNAL', message: 'Terjadi kesalahan pada server' };
  }
}
