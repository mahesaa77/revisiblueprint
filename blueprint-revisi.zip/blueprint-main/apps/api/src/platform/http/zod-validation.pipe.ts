import type { PipeTransform } from '@nestjs/common';
import type { z } from 'zod';
import { DomainError } from '../errors.js';

/** Validasi body/query memakai skema Zod dari @toko/contracts. */
export class ZodValidationPipe<T> implements PipeTransform<unknown, T> {
  constructor(private readonly schema: z.ZodType<T>) {}

  transform(value: unknown): T {
    const hasil = this.schema.safeParse(value);
    if (!hasil.success) {
      throw new DomainError('VALIDASI_GAGAL', 'Data permintaan tidak valid', 400, {
        isu: hasil.error.issues.map((i) => ({ path: i.path.join('.'), pesan: i.message })),
      });
    }
    return hasil.data;
  }
}
