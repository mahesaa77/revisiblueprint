/**
 * Error domain/aplikasi yang bebas dari framework. Filter HTTP di
 * platform/http menerjemahkannya ke amplop ErrorResponse (@toko/contracts).
 */
export class DomainError extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly statusCode: number = 400,
    readonly details?: Record<string, unknown>,
  ) {
    super(message);
    this.name = 'DomainError';
  }
}

export const tidakDitemukan = (code: string, message: string): DomainError =>
  new DomainError(code, message, 404);

export const konflik = (code: string, message: string): DomainError =>
  new DomainError(code, message, 409);
