export interface DomainEvent<T = unknown> {
  type: string;
  payload: T;
}

export type EventHandler = (event: DomainEvent) => void | Promise<void>;

/**
 * Port messaging. MESSAGE_DRIVER=inmemory dipakai sekarang; adapter RabbitMQ
 * menyusul di Fase 3 dengan kontrak yang sama (blueprint: event-driven).
 */
export abstract class EventBus {
  abstract publish(event: DomainEvent): Promise<void>;
  abstract subscribe(type: string, handler: EventHandler): void;
}

export class InMemoryEventBus extends EventBus {
  private readonly handlers = new Map<string, EventHandler[]>();

  subscribe(type: string, handler: EventHandler): void {
    this.handlers.set(type, [...(this.handlers.get(type) ?? []), handler]);
  }

  async publish(event: DomainEvent): Promise<void> {
    for (const handler of this.handlers.get(event.type) ?? []) {
      await handler(event);
    }
  }
}
