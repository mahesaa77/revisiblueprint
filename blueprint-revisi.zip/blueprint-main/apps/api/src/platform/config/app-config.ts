export interface AppConfig {
  /** Persen PPN. Default 0 sampai aturan fiskal diputuskan (PLAN.md Fase 0). */
  ppnPersen: number;
  /** Basis URL web untuk payload QR/barcode. */
  webBaseUrl: string;
  messageDriver: 'inmemory';
}

export const APP_CONFIG = 'APP_CONFIG';

export function bacaConfig(env: Record<string, string | undefined> = process.env): AppConfig {
  const ppn = Number(env['PPN_PERSEN'] ?? 0);
  if (!Number.isFinite(ppn) || ppn < 0 || ppn > 100) {
    throw new Error('PPN_PERSEN harus angka 0-100');
  }
  const driver = env['MESSAGE_DRIVER'] ?? 'inmemory';
  if (driver !== 'inmemory') {
    throw new Error(`MESSAGE_DRIVER=${driver} belum diimplementasi (rencana: Fase 3)`);
  }
  return {
    ppnPersen: ppn,
    webBaseUrl: env['WEB_BASE_URL'] ?? 'http://localhost:3001',
    messageDriver: 'inmemory',
  };
}
