import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module.js';

/**
 * Bootstrap backend modular monolith.
 * Prefix /api/v1 sesuai blueprint bagian 13 (REST versioning via path).
 */
async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule);
  app.setGlobalPrefix('api/v1');
  // Web (Next.js) berjalan di origin lain saat pengembangan.
  app.enableCors({ origin: process.env['CORS_ORIGIN']?.split(',') ?? ['http://localhost:3001'] });
  app.enableShutdownHooks();

  const port = Number(process.env['PORT'] ?? 3000);
  await app.listen(port, '0.0.0.0');
}

void bootstrap();
