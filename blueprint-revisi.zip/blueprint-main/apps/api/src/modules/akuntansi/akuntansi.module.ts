import { Module } from '@nestjs/common';
import { EventBus } from '../../platform/messaging/event-bus.js';
import { AkuntansiService } from './application/akuntansi.service.js';
import { AkuntansiController } from './presentation/akuntansi.controller.js';

@Module({
  controllers: [AkuntansiController],
  providers: [
    {
      provide: AkuntansiService,
      useFactory: (bus: EventBus) => {
        const service = new AkuntansiService();
        service.daftarkanHandler(bus);
        return service;
      },
      inject: [EventBus],
    },
  ],
  exports: [AkuntansiService],
})
export class AkuntansiModule {}
