import { DomainError } from '../../../platform/errors.js';

export interface BarisJurnal {
  akun: string;
  debit: number;
  kredit: number;
}

export interface Jurnal {
  readonly id: string;
  readonly waktu: string;
  readonly referensi: string;
  readonly keterangan: string;
  readonly baris: readonly Readonly<BarisJurnal>[];
}

/**
 * Membuat jurnal double-entry. Jurnal immutable (di-freeze) dan harus seimbang:
 * total debit == total kredit. Koreksi dilakukan dengan jurnal balik, bukan edit.
 */
export function buatJurnal(
  id: string,
  waktu: Date,
  referensi: string,
  keterangan: string,
  baris: BarisJurnal[],
): Jurnal {
  const aktif = baris.filter((b) => b.debit !== 0 || b.kredit !== 0);
  if (aktif.length < 2) throw new DomainError('JURNAL_INVALID', 'Jurnal minimal dua baris');
  for (const b of aktif) {
    const valid = Number.isInteger(b.debit) && Number.isInteger(b.kredit) && b.debit >= 0 && b.kredit >= 0;
    if (!valid || (b.debit > 0 && b.kredit > 0)) {
      throw new DomainError('JURNAL_INVALID', `Baris jurnal akun ${b.akun} tidak valid`, 500);
    }
  }
  const debit = aktif.reduce((n, b) => n + b.debit, 0);
  const kredit = aktif.reduce((n, b) => n + b.kredit, 0);
  if (debit !== kredit) {
    throw new DomainError('JURNAL_TIDAK_SEIMBANG', `Debit ${debit} != kredit ${kredit}`, 500);
  }
  return Object.freeze({
    id,
    waktu: waktu.toISOString(),
    referensi,
    keterangan,
    baris: Object.freeze(aktif.map((b) => Object.freeze({ ...b }))),
  });
}
