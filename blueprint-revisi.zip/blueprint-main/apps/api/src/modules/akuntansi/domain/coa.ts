export type KelompokAkun = 'ASET' | 'LIABILITAS' | 'EKUITAS' | 'PENDAPATAN' | 'BEBAN';

export interface Akun {
  kode: string;
  nama: string;
  kelompok: KelompokAkun;
  /** TRUE = akun dummy yang BELUM divalidasi akuntan (lihat PLAN.md, Fase 0). */
  isPlaceholder: boolean;
}

/**
 * PLACEHOLDER - Chart of Accounts dummy. Wajib diganti hasil validasi akuntan/
 * konsultan pajak sebelum go-live; laporan tidak boleh dipakai untuk keputusan pajak.
 */
export const COA_PLACEHOLDER: Akun[] = [
  { kode: '1101', nama: 'Kas', kelompok: 'ASET', isPlaceholder: true },
  { kode: '1102', nama: 'Kas Non-Tunai (QRIS/Kartu/E-Wallet)', kelompok: 'ASET', isPlaceholder: true },
  { kode: '1201', nama: 'Persediaan Barang Dagang', kelompok: 'ASET', isPlaceholder: true },
  { kode: '2101', nama: 'Uang Muka Pelanggan (DP Reservasi)', kelompok: 'LIABILITAS', isPlaceholder: true },
  { kode: '2102', nama: 'PPN Keluaran', kelompok: 'LIABILITAS', isPlaceholder: true },
  { kode: '4101', nama: 'Penjualan', kelompok: 'PENDAPATAN', isPlaceholder: true },
  { kode: '4102', nama: 'Diskon Penjualan', kelompok: 'PENDAPATAN', isPlaceholder: true },
  { kode: '4103', nama: 'Retur Penjualan', kelompok: 'PENDAPATAN', isPlaceholder: true },
  { kode: '5101', nama: 'Harga Pokok Penjualan', kelompok: 'BEBAN', isPlaceholder: true },
];
