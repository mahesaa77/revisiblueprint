import { buatJurnal } from './jurnal.js';

describe('buatJurnal', () => {
  const t = new Date('2026-11-27T00:00:00Z');
  it('menerima jurnal seimbang dan membekukannya', () => {
    const j = buatJurnal('J1', t, 'REF', 'tes', [
      { akun: '1101', debit: 100, kredit: 0 },
      { akun: '4101', debit: 0, kredit: 100 },
    ]);
    expect(Object.isFrozen(j)).toBe(true);
    expect(() => { (j.baris as unknown as { akun: string }[])[0]!.akun = 'X'; }).toThrow();
  });
  it('menolak jurnal tidak seimbang', () => {
    expect(() => buatJurnal('J2', t, 'REF', 'tes', [
      { akun: '1101', debit: 100, kredit: 0 },
      { akun: '4101', debit: 0, kredit: 90 },
    ])).toThrow('Debit');
  });
});
