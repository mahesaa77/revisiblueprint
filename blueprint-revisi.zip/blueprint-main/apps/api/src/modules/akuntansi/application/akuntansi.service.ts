import { tidakDitemukan } from '../../../platform/errors.js';
import type { EventBus } from '../../../platform/messaging/event-bus.js';
import { COA_PLACEHOLDER, type Akun } from '../domain/coa.js';
import { buatJurnal, type BarisJurnal, type Jurnal } from '../domain/jurnal.js';

export interface PenjualanEvent {
  id: string;
  subtotal: number;
  diskon: number;
  pajak: number;
  total: number;
  /** Penerimaan bersih (setelah kembalian). */
  tunai: number;
  nonTunai: number;
  hpp: number;
}

export interface ReturEvent {
  id: string;
  transaksiId: string;
  nilaiPenjualan: number;
  pajak: number;
  hpp: number;
}

export interface PelunasanEvent {
  id: string;
  dpDibayar: number;
  sisaTunai: number;
  totalPenjualan: number;
  hpp: number;
}

export interface DpEvent {
  id: string;
  jumlah: number;
}

/**
 * Akuntansi (M5): satu-satunya jalur pembuatan jurnal. Tidak ada endpoint input
 * jurnal manual - jurnal lahir dari event transaksi (single source of truth).
 */
export class AkuntansiService {
  private readonly buku: Jurnal[] = [];
  private seq = 0;

  constructor(private readonly now: () => Date = () => new Date()) {}

  daftarkanHandler(bus: EventBus): void {
    bus.subscribe('transaksi.dibuat', (e) => {
      this.catatPenjualan(e.payload as PenjualanEvent);
    });
    bus.subscribe('transaksi.retur', (e) => {
      this.catatRetur(e.payload as ReturEvent);
    });
    bus.subscribe('reservasi.dp-dibayar', (e) => {
      this.catatDp(e.payload as DpEvent);
    });
    bus.subscribe('reservasi.lunas', (e) => {
      this.catatPelunasan(e.payload as PelunasanEvent);
    });
  }

  catatPenjualan(p: PenjualanEvent): Jurnal {
    return this.simpan(`Penjualan ${p.id}`, p.id, [
      { akun: '1101', debit: p.tunai, kredit: 0 },
      { akun: '1102', debit: p.nonTunai, kredit: 0 },
      { akun: '4102', debit: p.diskon, kredit: 0 },
      { akun: '4101', debit: 0, kredit: p.subtotal },
      { akun: '2102', debit: 0, kredit: p.pajak },
      { akun: '5101', debit: p.hpp, kredit: 0 },
      { akun: '1201', debit: 0, kredit: p.hpp },
    ]);
  }

  catatRetur(r: ReturEvent): Jurnal {
    return this.simpan(`Retur ${r.id} atas ${r.transaksiId}`, r.id, [
      { akun: '4103', debit: r.nilaiPenjualan, kredit: 0 },
      { akun: '2102', debit: r.pajak, kredit: 0 },
      { akun: '1101', debit: 0, kredit: r.nilaiPenjualan + r.pajak },
      { akun: '1201', debit: r.hpp, kredit: 0 },
      { akun: '5101', debit: 0, kredit: r.hpp },
    ]);
  }

  catatDp(d: DpEvent): Jurnal {
    return this.simpan(`DP reservasi ${d.id}`, d.id, [
      { akun: '1102', debit: d.jumlah, kredit: 0 },
      { akun: '2101', debit: 0, kredit: d.jumlah },
    ]);
  }

  catatPelunasan(p: PelunasanEvent): Jurnal {
    return this.simpan(`Pelunasan reservasi ${p.id}`, p.id, [
      { akun: '1102', debit: p.sisaTunai, kredit: 0 },
      { akun: '2101', debit: p.dpDibayar, kredit: 0 },
      { akun: '4101', debit: 0, kredit: p.totalPenjualan },
      { akun: '5101', debit: p.hpp, kredit: 0 },
      { akun: '1201', debit: 0, kredit: p.hpp },
    ]);
  }

  daftarJurnal(): readonly Jurnal[] {
    return this.buku;
  }

  coa(): Akun[] {
    return COA_PLACEHOLDER;
  }

  neracaSaldo() {
    const baris = COA_PLACEHOLDER.map((akun) => {
      const { debit, kredit } = this.mutasi(akun.kode);
      const normalDebit = akun.kelompok === 'ASET' || akun.kelompok === 'BEBAN';
      return { ...akun, debit, kredit, saldo: normalDebit ? debit - kredit : kredit - debit };
    }).filter((b) => b.debit !== 0 || b.kredit !== 0);
    const totalDebit = baris.reduce((n, b) => n + b.debit, 0);
    const totalKredit = baris.reduce((n, b) => n + b.kredit, 0);
    return { baris, totalDebit, totalKredit, seimbang: totalDebit === totalKredit, peringatan: PERINGATAN_COA };
  }

  labaRugi() {
    const saldo = (kode: string, normalDebit: boolean) => {
      const m = this.mutasi(kode);
      return normalDebit ? m.debit - m.kredit : m.kredit - m.debit;
    };
    const penjualan = saldo('4101', false);
    const diskon = -saldo('4102', false);
    const retur = -saldo('4103', false);
    const pendapatanBersih = penjualan - diskon - retur;
    const hpp = saldo('5101', true);
    return {
      penjualan, diskon, retur, pendapatanBersih, hpp,
      labaKotor: pendapatanBersih - hpp,
      peringatan: PERINGATAN_COA,
    };
  }

  bukuBesar(kode: string) {
    const akun = COA_PLACEHOLDER.find((a) => a.kode === kode);
    if (!akun) throw tidakDitemukan('AKUN_TIDAK_DITEMUKAN', `Akun ${kode} tidak ada di COA`);
    const entri = this.buku.flatMap((j) =>
      j.baris.filter((b) => b.akun === kode).map((b) => ({
        jurnalId: j.id, waktu: j.waktu, keterangan: j.keterangan, debit: b.debit, kredit: b.kredit,
      })),
    );
    return { akun, entri, ...this.mutasi(kode) };
  }

  private mutasi(kode: string): { debit: number; kredit: number } {
    let debit = 0;
    let kredit = 0;
    for (const j of this.buku) {
      for (const b of j.baris) {
        if (b.akun === kode) {
          debit += b.debit;
          kredit += b.kredit;
        }
      }
    }
    return { debit, kredit };
  }

  private simpan(keterangan: string, referensi: string, baris: BarisJurnal[]): Jurnal {
    this.seq += 1;
    const jurnal = buatJurnal(`JRN-${String(this.seq).padStart(6, '0')}`, this.now(), referensi, keterangan, baris);
    this.buku.push(jurnal);
    return jurnal;
  }
}

const PERINGATAN_COA =
  'COA masih placeholder dan belum divalidasi akuntan; jangan dipakai untuk keputusan pajak.';

