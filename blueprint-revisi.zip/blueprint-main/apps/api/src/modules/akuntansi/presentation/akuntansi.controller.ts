import { Controller, Get, Param } from '@nestjs/common';
import { AkuntansiService } from '../application/akuntansi.service.js';

@Controller('laporan')
export class AkuntansiController {
  constructor(private readonly akuntansi: AkuntansiService) {}

  @Get('coa')
  coa() {
    return { data: this.akuntansi.coa() };
  }

  @Get('jurnal')
  jurnal() {
    return { data: this.akuntansi.daftarJurnal() };
  }

  @Get('neraca-saldo')
  neracaSaldo() {
    return this.akuntansi.neracaSaldo();
  }

  @Get('laba-rugi')
  labaRugi() {
    return this.akuntansi.labaRugi();
  }

  @Get('buku-besar/:kode')
  bukuBesar(@Param('kode') kode: string) {
    return this.akuntansi.bukuBesar(kode);
  }
}
