import { DomainError } from '../../../platform/errors.js';

export interface RingkasanHarga {
  subtotal: number;
  diskon: number;
  pajak: number;
  total: number;
}

/** Perhitungan total struk. Semua nilai rupiah bulat; pajak dibulatkan ke rupiah terdekat. */
export function hitungHarga(subtotal: number, diskon: number, ppnPersen: number): RingkasanHarga {
  if (diskon > subtotal) {
    throw new DomainError('DISKON_MELEBIHI_SUBTOTAL', 'Diskon tidak boleh melebihi subtotal');
  }
  const dpp = subtotal - diskon;
  const pajak = Math.round((dpp * ppnPersen) / 100);
  return { subtotal, diskon, pajak, total: dpp + pajak };
}

export interface Bayar {
  metode: 'TUNAI' | 'QRIS' | 'KARTU' | 'EWALLET';
  jumlah: number;
}

/**
 * Validasi split payment. Kelebihan bayar hanya boleh jadi kembalian dari uang tunai.
 * Mengembalikan penerimaan bersih (setelah kembalian) per kelompok tunai/non-tunai.
 */
export function bersihkanPembayaran(total: number, bayar: Bayar[]) {
  const tunaiMasuk = bayar.filter((b) => b.metode === 'TUNAI').reduce((n, b) => n + b.jumlah, 0);
  const nonTunai = bayar.filter((b) => b.metode !== 'TUNAI').reduce((n, b) => n + b.jumlah, 0);
  const dibayar = tunaiMasuk + nonTunai;
  if (dibayar < total) {
    throw new DomainError('PEMBAYARAN_KURANG', `Pembayaran ${dibayar} kurang dari total ${total}`);
  }
  const kembalian = dibayar - total;
  if (kembalian > tunaiMasuk) {
    throw new DomainError('PEMBAYARAN_NON_TUNAI_BERLEBIH', 'Pembayaran non-tunai tidak boleh melebihi total');
  }
  return { tunai: tunaiMasuk - kembalian, nonTunai, kembalian };
}
