import type { Bayar } from './hitung.js';

export interface ItemTerjual {
  sku: string;
  nama: string;
  qty: number;
  harga: number;
  hpp: number;
}

export interface Transaksi {
  id: string;
  idempotencyKey: string;
  waktu: string;
  items: ItemTerjual[];
  subtotal: number;
  diskon: number;
  pajak: number;
  total: number;
  pembayaran: Bayar[];
  kembalian: number;
  /** Jumlah per SKU yang sudah diretur. */
  diretur: Record<string, number>;
}
