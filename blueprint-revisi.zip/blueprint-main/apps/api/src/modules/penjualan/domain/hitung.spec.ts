import { bersihkanPembayaran, hitungHarga } from './hitung.js';

describe('hitungHarga', () => {
  it('menghitung diskon dan PPN', () => {
    expect(hitungHarga(100000, 10000, 11)).toEqual({ subtotal: 100000, diskon: 10000, pajak: 9900, total: 99900 });
  });
  it('menolak diskon melebihi subtotal', () => {
    expect(() => hitungHarga(1000, 2000, 0)).toThrow('Diskon');
  });
});

describe('bersihkanPembayaran', () => {
  it('kembalian diambil dari tunai', () => {
    expect(bersihkanPembayaran(90000, [{ metode: 'TUNAI', jumlah: 100000 }])).toEqual({ tunai: 90000, nonTunai: 0, kembalian: 10000 });
  });
  it('split payment tunai + QRIS', () => {
    const r = bersihkanPembayaran(150000, [{ metode: 'QRIS', jumlah: 100000 }, { metode: 'TUNAI', jumlah: 50000 }]);
    expect(r).toEqual({ tunai: 50000, nonTunai: 100000, kembalian: 0 });
  });
  it('menolak pembayaran kurang', () => {
    expect(() => bersihkanPembayaran(100, [{ metode: 'TUNAI', jumlah: 50 }])).toThrow('kurang');
  });
  it('menolak kelebihan non-tunai', () => {
    expect(() => bersihkanPembayaran(100, [{ metode: 'QRIS', jumlah: 150 }])).toThrow('non-tunai');
  });
});
