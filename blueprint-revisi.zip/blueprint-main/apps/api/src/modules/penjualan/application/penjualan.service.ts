import type { BuatTransaksi, Retur } from '@toko/contracts';
import { DomainError, konflik, tidakDitemukan } from '../../../platform/errors.js';
import type { EventBus } from '../../../platform/messaging/event-bus.js';
import type { ReturEvent, PenjualanEvent } from '../../akuntansi/application/akuntansi.service.js';
import type { ProdukRepository } from '../../katalog/domain/produk.js';
import { InventoriService } from '../../inventori/application/inventori.service.js';
import { bersihkanPembayaran, hitungHarga } from '../domain/hitung.js';
import type { ItemTerjual, Transaksi } from '../domain/transaksi.js';

export interface HasilTransaksi {
  transaksi: Transaksi;
  /** TRUE bila idempotencyKey sudah pernah diproses - transaksi lama dikembalikan, stok tidak dipotong lagi. */
  duplikat: boolean;
}

export interface HasilSync {
  idempotencyKey: string;
  status: 'DISIMPAN' | 'DUPLIKAT' | 'DITOLAK';
  transaksiId?: string;
  alasan?: { code: string; message: string };
}

export class PenjualanService {
  private readonly data = new Map<string, Transaksi>();
  private readonly perKey = new Map<string, string>();
  private seq = 0;
  private seqRetur = 0;

  constructor(
    private readonly produk: ProdukRepository,
    private readonly inventori: InventoriService,
    private readonly bus: EventBus,
    private readonly ppnPersen: number,
    private readonly now: () => Date = () => new Date(),
  ) {}

  async buat(input: BuatTransaksi): Promise<HasilTransaksi> {
    const lama = this.perKey.get(input.idempotencyKey);
    if (lama) return { transaksi: this.ambil(lama), duplikat: true };

    const items = this.gabungItem(input.items);
    const subtotal = items.reduce((n, i) => n + i.harga * i.qty, 0);
    const harga = hitungHarga(subtotal, input.diskon, this.ppnPersen);
    const bersih = bersihkanPembayaran(harga.total, input.pembayaran);

    this.seq += 1;
    const id = `TRX-${String(this.seq).padStart(6, '0')}`;
    // Pemotongan stok memeriksa semua SKU lebih dulu; gagal = tidak ada yang berubah.
    this.inventori.keluarBanyak(items.map(({ sku, qty }) => ({ sku, qty })), id);

    const transaksi: Transaksi = {
      id, idempotencyKey: input.idempotencyKey, waktu: this.now().toISOString(),
      items, ...harga, pembayaran: input.pembayaran, kembalian: bersih.kembalian, diretur: {},
    };
    this.data.set(id, transaksi);
    this.perKey.set(input.idempotencyKey, id);

    const event: PenjualanEvent = {
      id, subtotal: harga.subtotal, diskon: harga.diskon, pajak: harga.pajak, total: harga.total,
      tunai: bersih.tunai, nonTunai: bersih.nonTunai,
      hpp: items.reduce((n, i) => n + i.hpp * i.qty, 0),
    };
    await this.bus.publish({ type: 'transaksi.dibuat', payload: event });
    return { transaksi, duplikat: false };
  }

  /** Sinkron transaksi offline kasir: tiap item diproses independen dan idempoten. */
  async batchSync(daftar: BuatTransaksi[]): Promise<HasilSync[]> {
    const hasil: HasilSync[] = [];
    for (const t of daftar) {
      try {
        const r = await this.buat(t);
        hasil.push({
          idempotencyKey: t.idempotencyKey,
          status: r.duplikat ? 'DUPLIKAT' : 'DISIMPAN',
          transaksiId: r.transaksi.id,
        });
      } catch (e) {
        if (!(e instanceof DomainError)) throw e;
        hasil.push({ idempotencyKey: t.idempotencyKey, status: 'DITOLAK', alasan: { code: e.code, message: e.message } });
      }
    }
    return hasil;
  }

  ambil(id: string): Transaksi {
    const t = this.data.get(id);
    if (!t) throw tidakDitemukan('TRANSAKSI_TIDAK_DITEMUKAN', `Transaksi ${id} tidak ada`);
    return t;
  }

  async retur(id: string, input: Retur): Promise<{ returId: string; refund: number }> {
    const t = this.ambil(id);
    const diminta = this.gabungQty(input.items);
    for (const [sku, qty] of diminta) {
      const item = t.items.find((i) => i.sku === sku);
      if (!item) throw new DomainError('ITEM_BUKAN_DARI_TRANSAKSI', `SKU ${sku} tidak ada di ${id}`);
      const sisa = item.qty - (t.diretur[sku] ?? 0);
      if (qty > sisa) throw konflik('RETUR_MELEBIHI_PEMBELIAN', `Retur ${sku} melebihi sisa ${sisa}`);
    }
    this.seqRetur += 1;
    const returId = `RTR-${String(this.seqRetur).padStart(6, '0')}`;

    let bruto = 0;
    let hpp = 0;
    for (const [sku, qty] of diminta) {
      const item = t.items.find((i) => i.sku === sku) as ItemTerjual;
      bruto += item.harga * qty;
      hpp += item.hpp * qty;
      this.inventori.masuk(sku, qty, returId, 'RETUR');
      t.diretur[sku] = (t.diretur[sku] ?? 0) + qty;
    }
    // Nilai retur memakai harga setelah diskon proporsional.
    const nilai = t.subtotal === 0 ? 0 : Math.round((bruto * (t.subtotal - t.diskon)) / t.subtotal);
    const pajak = Math.round((nilai * this.ppnPersen) / 100);
    const event: ReturEvent = { id: returId, transaksiId: id, nilaiPenjualan: nilai, pajak, hpp };
    await this.bus.publish({ type: 'transaksi.retur', payload: event });
    return { returId, refund: nilai + pajak };
  }

  private gabungItem(items: BuatTransaksi['items']): ItemTerjual[] {
    const hasil: ItemTerjual[] = [];
    for (const [sku, qty] of this.gabungQty(items)) {
      const ditemukan = this.produk.cariSku(sku.toUpperCase());
      if (!ditemukan) throw tidakDitemukan('SKU_TIDAK_DITEMUKAN', `SKU ${sku} tidak terdaftar`);
      const { produk, varian } = ditemukan;
      hasil.push({ sku: varian.sku, nama: `${produk.nama} ${varian.warna}/${varian.ukuran}`, qty, harga: produk.harga, hpp: produk.hpp });
    }
    return hasil;
  }

  private gabungQty(items: { sku: string; qty: number }[]): Map<string, number> {
    const m = new Map<string, number>();
    for (const { sku, qty } of items) m.set(sku, (m.get(sku) ?? 0) + qty);
    return m;
  }
}
