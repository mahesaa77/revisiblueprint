import { buatSistem } from '../../../../test/sistem.js';

const kunci = (n: number) => `kunci-offline-${n}`;

describe('PenjualanService', () => {
  it('transaksi memotong stok dan otomatis membuat jurnal seimbang', async () => {
    const { penjualan, inventori, akuntansi } = buatSistem(11);
    const { transaksi } = await penjualan.buat({
      idempotencyKey: kunci(1),
      items: [{ sku: 'KAO-BSC-HTM-M', qty: 2 }, { sku: 'CLN-CHN-KHK-32', qty: 1 }],
      diskon: 8000,
      pembayaran: [{ metode: 'QRIS', jumlah: 350000 }, { metode: 'TUNAI', jumlah: 200000 }],
    });
    // subtotal 2*89000 + 299000 = 477000; dpp 469000; pajak 51590; total 520590
    expect(transaksi.total).toBe(520590);
    expect(transaksi.kembalian).toBe(29410);
    expect(inventori.tersedia('KAO-BSC-HTM-M')).toBe(23);
    const neraca = akuntansi.neracaSaldo();
    expect(neraca.seimbang).toBe(true);
    expect(akuntansi.daftarJurnal()).toHaveLength(1);
  });

  it('pembayaran kurang ditolak tanpa mengubah stok', async () => {
    const { penjualan, inventori } = buatSistem();
    await expect(
      penjualan.buat({ idempotencyKey: kunci(2), items: [{ sku: 'KAO-BSC-HTM-M', qty: 1 }], diskon: 0, pembayaran: [{ metode: 'TUNAI', jumlah: 1000 }] }),
    ).rejects.toMatchObject({ code: 'PEMBAYARAN_KURANG' });
    expect(inventori.tersedia('KAO-BSC-HTM-M')).toBe(25);
  });

  it('stok habis ditolak (stok tidak pernah minus)', async () => {
    const { penjualan } = buatSistem();
    await expect(
      penjualan.buat({ idempotencyKey: kunci(3), items: [{ sku: 'KMJ-OXF-PTH-L', qty: 1 }], diskon: 0, pembayaran: [{ metode: 'TUNAI', jumlah: 999999 }] }),
    ).rejects.toMatchObject({ code: 'STOK_TIDAK_CUKUP', statusCode: 409 });
  });

  it('idempotencyKey sama tidak menggandakan transaksi', async () => {
    const { penjualan, inventori } = buatSistem();
    const input = { idempotencyKey: kunci(4), items: [{ sku: 'KAO-BSC-ABU-M', qty: 3 }], diskon: 0, pembayaran: [{ metode: 'TUNAI' as const, jumlah: 300000 }] };
    const a = await penjualan.buat(input);
    const b = await penjualan.buat(input);
    expect(b.duplikat).toBe(true);
    expect(b.transaksi.id).toBe(a.transaksi.id);
    expect(inventori.tersedia('KAO-BSC-ABU-M')).toBe(7);
  });

  it('batch-sync: stok terakhir direbut, sisanya ditolak tanpa stok minus', async () => {
    const { penjualan, inventori } = buatSistem();
    const buat = (n: number) => ({ idempotencyKey: kunci(10 + n), items: [{ sku: 'JKT-HOD-MRN-XL', qty: 2 }], diskon: 0, pembayaran: [{ metode: 'TUNAI' as const, jumlah: 700000 }] });
    const hasil = await penjualan.batchSync([buat(1), buat(2), buat(1)]);
    expect(hasil.map((h) => h.status)).toEqual(['DISIMPAN', 'DITOLAK', 'DUPLIKAT']);
    expect(hasil[1]?.alasan?.code).toBe('STOK_TIDAK_CUKUP');
    expect(inventori.tersedia('JKT-HOD-MRN-XL')).toBe(1);
  });

  it('retur mengembalikan stok dan jurnal tetap seimbang', async () => {
    const { penjualan, inventori, akuntansi } = buatSistem();
    const { transaksi } = await penjualan.buat({ idempotencyKey: kunci(5), items: [{ sku: 'ROK-PLS-SGE-ALL', qty: 2 }], diskon: 0, pembayaran: [{ metode: 'TUNAI', jumlah: 378000 }] });
    const r = await penjualan.retur(transaksi.id, { items: [{ sku: 'ROK-PLS-SGE-ALL', qty: 1 }] });
    expect(r.refund).toBe(189000);
    expect(inventori.tersedia('ROK-PLS-SGE-ALL')).toBe(10);
    expect(akuntansi.neracaSaldo().seimbang).toBe(true);
    await expect(penjualan.retur(transaksi.id, { items: [{ sku: 'ROK-PLS-SGE-ALL', qty: 2 }] })).rejects.toMatchObject({ code: 'RETUR_MELEBIHI_PEMBELIAN' });
  });
});
