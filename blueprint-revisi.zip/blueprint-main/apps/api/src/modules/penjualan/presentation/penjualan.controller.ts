import { Body, Controller, Get, HttpCode, Param, Post, Res } from '@nestjs/common';
import type { Response } from 'express';
import {
  batchSyncSchema, buatTransaksiSchema, returSchema,
  type BatchSync, type BuatTransaksi, type Retur,
} from '@toko/contracts';
import { ZodValidationPipe } from '../../../platform/http/zod-validation.pipe.js';
import { PenjualanService } from '../application/penjualan.service.js';

@Controller('transaksi')
export class PenjualanController {
  constructor(private readonly penjualan: PenjualanService) {}

  @Post()
  async buat(
    @Body(new ZodValidationPipe(buatTransaksiSchema)) body: BuatTransaksi,
    @Res({ passthrough: true }) res: Response,
  ) {
    const hasil = await this.penjualan.buat(body);
    // Permintaan ulang dengan idempotencyKey sama dijawab 200, bukan 201.
    res.status(hasil.duplikat ? 200 : 201);
    return hasil;
  }

  @Post('batch-sync')
  @HttpCode(200)
  async batchSync(@Body(new ZodValidationPipe(batchSyncSchema)) body: BatchSync) {
    return { hasil: await this.penjualan.batchSync(body.transaksi) };
  }

  @Get(':id')
  ambil(@Param('id') id: string) {
    return this.penjualan.ambil(id);
  }

  @Post(':id/retur')
  @HttpCode(201)
  retur(@Param('id') id: string, @Body(new ZodValidationPipe(returSchema)) body: Retur) {
    return this.penjualan.retur(id, body);
  }
}
