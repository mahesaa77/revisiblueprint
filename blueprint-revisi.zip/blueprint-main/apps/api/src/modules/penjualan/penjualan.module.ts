import { Module } from '@nestjs/common';
import { APP_CONFIG, type AppConfig } from '../../platform/config/app-config.js';
import { EventBus } from '../../platform/messaging/event-bus.js';
import { InventoriService } from '../inventori/application/inventori.service.js';
import { InventoriModule } from '../inventori/inventori.module.js';
import { ProdukRepository } from '../katalog/domain/produk.js';
import { KatalogModule } from '../katalog/katalog.module.js';
import { PenjualanService } from './application/penjualan.service.js';
import { PenjualanController } from './presentation/penjualan.controller.js';

@Module({
  imports: [KatalogModule, InventoriModule],
  controllers: [PenjualanController],
  providers: [
    {
      provide: PenjualanService,
      useFactory: (p: ProdukRepository, inv: InventoriService, bus: EventBus, cfg: AppConfig) =>
        new PenjualanService(p, inv, bus, cfg.ppnPersen),
      inject: [ProdukRepository, InventoriService, EventBus, APP_CONFIG],
    },
  ],
})
export class PenjualanModule {}
