import { Body, Controller, Get, HttpCode, Param, Post, Put } from '@nestjs/common';
import {
  buatReservasiSchema, konfigurasiDpSchema,
  type BuatReservasi, type KonfigurasiDp,
} from '@toko/contracts';
import { ZodValidationPipe } from '../../../platform/http/zod-validation.pipe.js';
import { ReservasiService } from '../application/reservasi.service.js';

@Controller()
export class ReservasiController {
  constructor(private readonly reservasi: ReservasiService) {}

  @Post('reservasi')
  @HttpCode(201)
  buat(@Body(new ZodValidationPipe(buatReservasiSchema)) body: BuatReservasi) {
    return this.reservasi.buat(body);
  }

  @Get('reservasi/:id')
  ambil(@Param('id') id: string) {
    return this.reservasi.ambil(id);
  }

  @Post('reservasi/:id/bayar-dp')
  @HttpCode(200)
  bayarDp(@Param('id') id: string) {
    return this.reservasi.bayarDp(id);
  }

  @Post('reservasi/:id/lunasi')
  @HttpCode(200)
  lunasi(@Param('id') id: string) {
    return this.reservasi.lunasi(id);
  }

  @Post('reservasi/:id/batal')
  @HttpCode(200)
  batal(@Param('id') id: string) {
    return this.reservasi.batalkan(id);
  }

  @Get('admin/konfigurasi-dp')
  ambilKonfigurasi() {
    return this.reservasi.ambilKonfigurasi();
  }

  @Put('admin/konfigurasi-dp')
  aturKonfigurasi(@Body(new ZodValidationPipe(konfigurasiDpSchema)) body: KonfigurasiDp) {
    return this.reservasi.aturKonfigurasi(body);
  }
}
