import { Module } from '@nestjs/common';
import { EventBus } from '../../platform/messaging/event-bus.js';
import { InventoriService } from '../inventori/application/inventori.service.js';
import { InventoriModule } from '../inventori/inventori.module.js';
import { ProdukRepository } from '../katalog/domain/produk.js';
import { KatalogModule } from '../katalog/katalog.module.js';
import { ReservasiService } from './application/reservasi.service.js';
import { ReservasiController } from './presentation/reservasi.controller.js';

@Module({
  imports: [KatalogModule, InventoriModule],
  controllers: [ReservasiController],
  providers: [
    {
      provide: ReservasiService,
      useFactory: (p: ProdukRepository, inv: InventoriService, bus: EventBus) =>
        new ReservasiService(p, inv, bus),
      inject: [ProdukRepository, InventoriService, EventBus],
    },
  ],
})
export class ReservasiModule {}
