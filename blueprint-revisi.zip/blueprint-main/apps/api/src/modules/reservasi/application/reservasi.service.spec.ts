import { buatSistem } from '../../../../test/sistem.js';

const data = { sku: 'CLN-CHN-NVY-32', qty: 2, namaPelanggan: 'Sari Dewi', kontak: '08123456789' };

describe('ReservasiService', () => {
  it('menghitung DP persen sesuai konfigurasi admin dan menahan stok', () => {
    const { reservasi, inventori } = buatSistem();
    const r = reservasi.buat(data);
    expect(r.total).toBe(598000);
    expect(r.dp).toBe(179400); // 30%
    expect(inventori.tersedia('CLN-CHN-NVY-32')).toBe(2);
  });

  it('DP nominal tetap dibatasi total', () => {
    const { reservasi } = buatSistem();
    reservasi.aturKonfigurasi({ tipe: 'NOMINAL', nilai: 50000, holdJam: 48 });
    expect(reservasi.buat(data).dp).toBe(50000);
  });

  it('alur lengkap: DP -> lunas, jurnal seimbang, hold menjadi penjualan', async () => {
    const { reservasi, inventori, akuntansi } = buatSistem();
    const r = reservasi.buat(data);
    await reservasi.bayarDp(r.id);
    await reservasi.lunasi(r.id);
    expect(reservasi.ambil(r.id).status).toBe('LUNAS');
    expect(inventori.tersedia('CLN-CHN-NVY-32')).toBe(2);
    expect(akuntansi.neracaSaldo().seimbang).toBe(true);
    expect(akuntansi.labaRugi().labaKotor).toBe(598000 - 300000);
  });

  it('auto-release hold bila melewati batas waktu', () => {
    const { reservasi, inventori, majukanJam } = buatSistem();
    const r = reservasi.buat(data);
    majukanJam(25);
    expect(reservasi.ambil(r.id).status).toBe('KEDALUWARSA');
    expect(inventori.tersedia('CLN-CHN-NVY-32')).toBe(4);
  });

  it('stok tidak cukup untuk di-hold ditolak', () => {
    const { reservasi } = buatSistem();
    expect(() => reservasi.buat({ ...data, qty: 5 })).toThrow('tidak cukup');
  });

  it('batal setelah DP dibayar ditolak sampai kebijakan refund ada', async () => {
    const { reservasi } = buatSistem();
    const r = reservasi.buat(data);
    await reservasi.bayarDp(r.id);
    expect(() => reservasi.batalkan(r.id)).toThrow('kebijakan refund');
  });
});
