import type { BuatReservasi, KonfigurasiDp } from '@toko/contracts';
import { DomainError, konflik, tidakDitemukan } from '../../../platform/errors.js';
import type { EventBus } from '../../../platform/messaging/event-bus.js';
import type { DpEvent, PelunasanEvent } from '../../akuntansi/application/akuntansi.service.js';
import { InventoriService } from '../../inventori/application/inventori.service.js';
import type { ProdukRepository } from '../../katalog/domain/produk.js';
import type { Reservasi } from '../domain/reservasi.js';

const JAM = 3_600_000;

export class ReservasiService {
  private konfigurasi: KonfigurasiDp = { tipe: 'PERSEN', nilai: 30, holdJam: 24 };
  private readonly data = new Map<string, Reservasi>();
  private seq = 0;

  constructor(
    private readonly produk: ProdukRepository,
    private readonly inventori: InventoriService,
    private readonly bus: EventBus,
    private readonly now: () => Date = () => new Date(),
  ) {}

  ambilKonfigurasi(): KonfigurasiDp {
    return { ...this.konfigurasi };
  }

  /** Admin mengatur skema DP. Persen maksimal 100. */
  aturKonfigurasi(k: KonfigurasiDp): KonfigurasiDp {
    if (k.tipe === 'PERSEN' && k.nilai > 100) {
      throw new DomainError('DP_PERSEN_INVALID', 'Persentase DP maksimal 100');
    }
    this.konfigurasi = { ...k };
    return this.ambilKonfigurasi();
  }

  buat(input: BuatReservasi): Reservasi {
    this.lepasKadaluarsa();
    const ketemu = this.produk.cariSku(input.sku.toUpperCase());
    if (!ketemu) throw tidakDitemukan('SKU_TIDAK_DITEMUKAN', `SKU ${input.sku} tidak terdaftar`);

    this.seq += 1;
    const id = `RSV-${String(this.seq).padStart(6, '0')}`;
    this.inventori.hold(ketemu.varian.sku, input.qty, id);

    const total = ketemu.produk.harga * input.qty;
    const dp = this.hitungDp(total);
    const mulai = this.now();
    const reservasi: Reservasi = {
      id, sku: ketemu.varian.sku, qty: input.qty,
      namaPelanggan: input.namaPelanggan, kontak: input.kontak,
      total, dp, sisa: total - dp, hpp: ketemu.produk.hpp * input.qty,
      status: 'MENUNGGU_DP',
      dibuatPada: mulai.toISOString(),
      batasWaktu: new Date(mulai.getTime() + this.konfigurasi.holdJam * JAM).toISOString(),
      dpPerluDitinjau: false,
    };
    this.data.set(id, reservasi);
    return reservasi;
  }

  async bayarDp(id: string): Promise<Reservasi> {
    const r = this.ambilAktual(id);
    if (r.status !== 'MENUNGGU_DP') throw konflik('STATUS_TIDAK_VALID', `Reservasi ${id} berstatus ${r.status}`);
    r.status = 'DP_DIBAYAR';
    const event: DpEvent = { id: r.id, jumlah: r.dp };
    await this.bus.publish({ type: 'reservasi.dp-dibayar', payload: event });
    return r;
  }

  async lunasi(id: string): Promise<Reservasi> {
    const r = this.ambilAktual(id);
    if (r.status !== 'DP_DIBAYAR') throw konflik('STATUS_TIDAK_VALID', `Reservasi ${id} berstatus ${r.status}`);
    this.inventori.konfirmasiHold(r.sku, r.qty, r.id);
    r.status = 'LUNAS';
    const event: PelunasanEvent = {
      id: r.id, dpDibayar: r.dp, sisaTunai: r.sisa, totalPenjualan: r.total, hpp: r.hpp,
    };
    await this.bus.publish({ type: 'reservasi.lunas', payload: event });
    return r;
  }

  /** Pembatalan hanya sebelum DP dibayar; kebijakan refund DP belum diputuskan (PLAN.md Fase 0). */
  batalkan(id: string): Reservasi {
    const r = this.ambilAktual(id);
    if (r.status !== 'MENUNGGU_DP') {
      throw new DomainError('REFUND_BELUM_DITENTUKAN', 'Pembatalan setelah DP dibayar menunggu kebijakan refund', 409);
    }
    this.inventori.lepasHold(r.sku, r.qty, r.id);
    r.status = 'DIBATALKAN';
    return r;
  }

  /**
   * Auto-release hold yang lewat batas waktu. Dipanggil di awal operasi sebagai
   * pengganti job BullMQ (Fase 3), supaya perilakunya sudah teruji sekarang.
   */
  lepasKadaluarsa(): string[] {
    const sekarang = this.now().getTime();
    const dilepas: string[] = [];
    for (const r of this.data.values()) {
      const aktif = r.status === 'MENUNGGU_DP' || r.status === 'DP_DIBAYAR';
      if (aktif && new Date(r.batasWaktu).getTime() <= sekarang) {
        this.inventori.lepasHold(r.sku, r.qty, r.id);
        r.dpPerluDitinjau = r.status === 'DP_DIBAYAR';
        r.status = 'KEDALUWARSA';
        dilepas.push(r.id);
      }
    }
    return dilepas;
  }

  ambil(id: string): Reservasi {
    this.lepasKadaluarsa();
    const r = this.data.get(id);
    if (!r) throw tidakDitemukan('RESERVASI_TIDAK_DITEMUKAN', `Reservasi ${id} tidak ada`);
    return r;
  }

  private ambilAktual(id: string): Reservasi {
    return this.ambil(id);
  }

  private hitungDp(total: number): number {
    const { tipe, nilai } = this.konfigurasi;
    return tipe === 'PERSEN' ? Math.round((total * nilai) / 100) : Math.min(nilai, total);
  }
}
