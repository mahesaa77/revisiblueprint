import type { StatusReservasi } from '@toko/contracts';

export interface Reservasi {
  id: string;
  sku: string;
  qty: number;
  namaPelanggan: string;
  kontak: string;
  total: number;
  dp: number;
  sisa: number;
  hpp: number;
  status: StatusReservasi;
  dibuatPada: string;
  batasWaktu: string;
  /** TRUE bila reservasi kedaluwarsa setelah DP dibayar: kebijakan DP hangus/refund belum diputuskan. */
  dpPerluDitinjau: boolean;
}
