import { InventoriService } from './inventori.service.js';

describe('InventoriService', () => {
  const buat = () => {
    const s = new InventoriService();
    s.daftarkan('SKU-A', 5);
    s.daftarkan('SKU-B', 2);
    return s;
  };

  it('stok tidak boleh minus', () => {
    const s = buat();
    expect(() => s.keluarBanyak([{ sku: 'SKU-A', qty: 6 }], 'T1')).toThrow('tidak cukup');
    expect(s.tersedia('SKU-A')).toBe(5);
  });

  it('keluarBanyak bersifat all-or-nothing', () => {
    const s = buat();
    expect(() => s.keluarBanyak([{ sku: 'SKU-A', qty: 1 }, { sku: 'SKU-B', qty: 3 }], 'T1')).toThrow();
    expect(s.tersedia('SKU-A')).toBe(5);
  });

  it('hold mengurangi stok tersedia dan dilepas kembali', () => {
    const s = buat();
    s.hold('SKU-A', 4, 'R1');
    expect(s.tersedia('SKU-A')).toBe(1);
    expect(() => s.hold('SKU-A', 2, 'R2')).toThrow('tidak cukup');
    s.lepasHold('SKU-A', 4, 'R1');
    expect(s.tersedia('SKU-A')).toBe(5);
  });

  it('kartu stok mencatat setiap pergerakan', () => {
    const s = buat();
    s.keluarBanyak([{ sku: 'SKU-A', qty: 2 }], 'TRX-1');
    const jenis = s.riwayat('SKU-A').map((g) => g.jenis);
    expect(jenis).toEqual(['MASUK', 'KELUAR']);
  });

  it('SKU tak dikenal ditolak', () => {
    expect(() => buat().tersedia('NOPE')).toThrow('tidak terdaftar');
  });
});
