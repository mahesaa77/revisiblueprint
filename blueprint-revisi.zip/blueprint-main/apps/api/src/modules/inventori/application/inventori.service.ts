import { DomainError, konflik, tidakDitemukan } from '../../../platform/errors.js';
import type { GerakStok, JenisGerak } from '../domain/kartu-stok.js';

interface SaldoStok {
  fisik: number;
  hold: number;
}

export interface ItemStok {
  sku: string;
  qty: number;
}

/**
 * Inventori produk jadi (M4, level 1). Aturan inti: stok tidak boleh minus.
 * Implementasi in-memory ini memeriksa lalu menulis tanpa await di antaranya,
 * sehingga atomik di satu proses Node. Saat pindah ke PostgreSQL, aturan yang
 * sama harus dipindah ke level DB (optimistic locking / CHECK constraint).
 */
export class InventoriService {
  private readonly saldo = new Map<string, SaldoStok>();
  private readonly kartu: GerakStok[] = [];

  constructor(private readonly now: () => Date = () => new Date()) {}

  daftarkan(sku: string, stokAwal: number): void {
    if (!Number.isInteger(stokAwal) || stokAwal < 0) {
      throw new DomainError('STOK_AWAL_INVALID', 'Stok awal harus bilangan bulat >= 0');
    }
    if (!this.saldo.has(sku)) {
      this.saldo.set(sku, { fisik: stokAwal, hold: 0 });
      this.catat(sku, 'MASUK', stokAwal, 'STOK-AWAL');
    }
  }

  tersedia(sku: string): number {
    const s = this.ambil(sku);
    return s.fisik - s.hold;
  }

  ada(sku: string): boolean {
    return this.saldo.has(sku);
  }

  masuk(sku: string, qty: number, referensi: string, jenis: JenisGerak = 'MASUK'): void {
    this.pastikanQty(qty);
    const s = this.ambil(sku);
    s.fisik += qty;
    this.catat(sku, jenis, qty, referensi);
  }

  /** Keluarkan banyak SKU sekaligus: semua diperiksa dulu, baru dikurangi (all-or-nothing). */
  keluarBanyak(items: ItemStok[], referensi: string): void {
    this.periksaCukup(items);
    for (const { sku, qty } of items) {
      this.ambil(sku).fisik -= qty;
      this.catat(sku, 'KELUAR', qty, referensi);
    }
  }

  hold(sku: string, qty: number, referensi: string): void {
    this.periksaCukup([{ sku, qty }]);
    this.ambil(sku).hold += qty;
    this.catat(sku, 'HOLD', qty, referensi);
  }

  lepasHold(sku: string, qty: number, referensi: string): void {
    const s = this.ambil(sku);
    if (qty > s.hold) throw konflik('HOLD_TIDAK_CUKUP', `Hold ${sku} hanya ${s.hold}`);
    s.hold -= qty;
    this.catat(sku, 'LEPAS_HOLD', qty, referensi);
  }

  /** Hold berubah menjadi penjualan: fisik dan hold sama-sama berkurang. */
  konfirmasiHold(sku: string, qty: number, referensi: string): void {
    const s = this.ambil(sku);
    if (qty > s.hold) throw konflik('HOLD_TIDAK_CUKUP', `Hold ${sku} hanya ${s.hold}`);
    s.hold -= qty;
    s.fisik -= qty;
    this.catat(sku, 'KONFIRMASI_HOLD', qty, referensi);
  }

  riwayat(sku: string): GerakStok[] {
    this.ambil(sku);
    return this.kartu.filter((g) => g.sku === sku).map((g) => ({ ...g }));
  }

  private periksaCukup(items: ItemStok[]): void {
    const butuh = new Map<string, number>();
    for (const { sku, qty } of items) {
      this.pastikanQty(qty);
      butuh.set(sku, (butuh.get(sku) ?? 0) + qty);
    }
    for (const [sku, qty] of butuh) {
      const ada = this.tersedia(sku);
      if (qty > ada) {
        throw konflik('STOK_TIDAK_CUKUP', `Stok ${sku} tidak cukup (diminta ${qty}, tersedia ${ada})`);
      }
    }
  }

  private pastikanQty(qty: number): void {
    if (!Number.isInteger(qty) || qty <= 0) {
      throw new DomainError('QTY_INVALID', 'Qty harus bilangan bulat > 0');
    }
  }

  private ambil(sku: string): SaldoStok {
    const s = this.saldo.get(sku);
    if (!s) throw tidakDitemukan('SKU_TIDAK_DITEMUKAN', `SKU ${sku} tidak terdaftar`);
    return s;
  }

  private catat(sku: string, jenis: JenisGerak, qty: number, referensi: string): void {
    const s = this.ambil(sku);
    this.kartu.push({
      sku, jenis, qty, referensi,
      waktu: this.now().toISOString(),
      saldoFisik: s.fisik,
      saldoHold: s.hold,
    });
  }
}
