import { Module } from '@nestjs/common';
import { InventoriService } from './application/inventori.service.js';
import { InventoriController } from './presentation/inventori.controller.js';

@Module({
  controllers: [InventoriController],
  providers: [{ provide: InventoriService, useFactory: () => new InventoriService() }],
  exports: [InventoriService],
})
export class InventoriModule {}
