import { Body, Controller, Get, HttpCode, Param, Post } from '@nestjs/common';
import { stokMasukSchema, type StokMasuk } from '@toko/contracts';
import { ZodValidationPipe } from '../../../platform/http/zod-validation.pipe.js';
import { InventoriService } from '../application/inventori.service.js';

@Controller('stok')
export class InventoriController {
  constructor(private readonly inventori: InventoriService) {}

  @Post('masuk')
  @HttpCode(201)
  masuk(@Body(new ZodValidationPipe(stokMasukSchema)) body: StokMasuk) {
    this.inventori.masuk(body.sku, body.qty, body.catatan ?? 'STOK-MASUK-MANUAL');
    return { sku: body.sku, tersedia: this.inventori.tersedia(body.sku) };
  }

  @Get(':sku/kartu')
  kartu(@Param('sku') sku: string) {
    return { sku, tersedia: this.inventori.tersedia(sku), riwayat: this.inventori.riwayat(sku) };
  }
}
