export type JenisGerak = 'MASUK' | 'KELUAR' | 'HOLD' | 'LEPAS_HOLD' | 'KONFIRMASI_HOLD' | 'RETUR';

/** Satu baris kartu stok - riwayat pergerakan untuk traceability dan audit. */
export interface GerakStok {
  sku: string;
  jenis: JenisGerak;
  qty: number;
  referensi: string;
  waktu: string;
  saldoFisik: number;
  saldoHold: number;
}
