import { Module } from '@nestjs/common';
import { APP_CONFIG, type AppConfig } from '../../platform/config/app-config.js';
import { InventoriModule } from '../inventori/inventori.module.js';
import { InventoriService } from '../inventori/application/inventori.service.js';
import { KatalogService } from './application/katalog.service.js';
import { ProdukRepository } from './domain/produk.js';
import { ProdukMemoryRepository } from './infrastructure/produk-memory.repository.js';
import { KatalogController } from './presentation/katalog.controller.js';

@Module({
  imports: [InventoriModule],
  controllers: [KatalogController],
  providers: [
    { provide: ProdukRepository, useFactory: () => new ProdukMemoryRepository() },
    {
      provide: KatalogService,
      useFactory: (repo: ProdukRepository, inv: InventoriService, cfg: AppConfig) =>
        new KatalogService(repo, inv, cfg.webBaseUrl),
      inject: [ProdukRepository, InventoriService, APP_CONFIG],
    },
  ],
  exports: [ProdukRepository, KatalogService],
})
export class KatalogModule {}
