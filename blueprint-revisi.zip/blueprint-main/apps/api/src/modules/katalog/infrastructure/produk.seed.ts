import type { ProdukData } from '../domain/produk.js';

/** Data contoh toko pakaian. Bukan data produksi. */
export const PRODUK_SEED: ProdukData[] = [
  {
    id: 'p-kemeja-oxford', nama: 'Kemeja Oxford Lengan Panjang', kategori: 'kemeja',
    deskripsi: 'Katun oxford 100%, potongan regular fit, cocok untuk kantor maupun santai.',
    harga: 245000, hpp: 120000,
    varian: [
      { sku: 'KMJ-OXF-BIR-M', ukuran: 'M', warna: 'Biru', stokAwal: 12 },
      { sku: 'KMJ-OXF-BIR-L', ukuran: 'L', warna: 'Biru', stokAwal: 8 },
      { sku: 'KMJ-OXF-PTH-M', ukuran: 'M', warna: 'Putih', stokAwal: 5 },
      { sku: 'KMJ-OXF-PTH-L', ukuran: 'L', warna: 'Putih', stokAwal: 0 },
    ],
  },
  {
    id: 'p-kaos-basic', nama: 'Kaos Basic Cotton Combed 30s', kategori: 'kaos',
    deskripsi: 'Kaos polos adem dan lembut, jahitan rantai di bahu agar tidak mudah melar.',
    harga: 89000, hpp: 38000,
    varian: [
      { sku: 'KAO-BSC-HTM-S', ukuran: 'S', warna: 'Hitam', stokAwal: 20 },
      { sku: 'KAO-BSC-HTM-M', ukuran: 'M', warna: 'Hitam', stokAwal: 25 },
      { sku: 'KAO-BSC-HTM-L', ukuran: 'L', warna: 'Hitam', stokAwal: 15 },
      { sku: 'KAO-BSC-ABU-M', ukuran: 'M', warna: 'Abu', stokAwal: 10 },
    ],
  },
  {
    id: 'p-chino', nama: 'Celana Chino Slim Fit', kategori: 'celana',
    deskripsi: 'Twill stretch dengan potongan slim, nyaman dipakai seharian.',
    harga: 299000, hpp: 150000,
    varian: [
      { sku: 'CLN-CHN-KHK-30', ukuran: '30', warna: 'Khaki', stokAwal: 6 },
      { sku: 'CLN-CHN-KHK-32', ukuran: '32', warna: 'Khaki', stokAwal: 9 },
      { sku: 'CLN-CHN-NVY-32', ukuran: '32', warna: 'Navy', stokAwal: 4 },
    ],
  },
  {
    id: 'p-hoodie', nama: 'Hoodie Fleece Oversize', kategori: 'jaket',
    deskripsi: 'Fleece tebal bagian dalam, kantong kangguru, siluet oversize.',
    harga: 329000, hpp: 165000,
    varian: [
      { sku: 'JKT-HOD-MRN-L', ukuran: 'L', warna: 'Marun', stokAwal: 7 },
      { sku: 'JKT-HOD-MRN-XL', ukuran: 'XL', warna: 'Marun', stokAwal: 3 },
    ],
  },
  {
    id: 'p-batik', nama: 'Kemeja Batik Parang Modern', kategori: 'kemeja',
    deskripsi: 'Batik cap motif parang, bahan katun primisima, lengan pendek.',
    harga: 275000, hpp: 140000,
    varian: [
      { sku: 'KMJ-BTK-CKL-M', ukuran: 'M', warna: 'Cokelat', stokAwal: 5 },
      { sku: 'KMJ-BTK-CKL-L', ukuran: 'L', warna: 'Cokelat', stokAwal: 5 },
    ],
  },
  {
    id: 'p-rok', nama: 'Rok Plisket Midi', kategori: 'rok',
    deskripsi: 'Rok plisket jatuh dengan karet pinggang, tidak perlu disetrika.',
    harga: 189000, hpp: 85000,
    varian: [
      { sku: 'ROK-PLS-SGE-ALL', ukuran: 'All Size', warna: 'Sage', stokAwal: 11 },
      { sku: 'ROK-PLS-HTM-ALL', ukuran: 'All Size', warna: 'Hitam', stokAwal: 14 },
    ],
  },
];
