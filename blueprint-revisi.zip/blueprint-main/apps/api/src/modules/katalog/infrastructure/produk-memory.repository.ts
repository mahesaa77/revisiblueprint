import { ProdukRepository, type HasilSku, type ProdukData } from '../domain/produk.js';
import { PRODUK_SEED } from './produk.seed.js';

export class ProdukMemoryRepository extends ProdukRepository {
  constructor(private readonly data: ProdukData[] = PRODUK_SEED) {
    super();
  }

  semua(): ProdukData[] {
    return this.data;
  }

  cariSku(sku: string): HasilSku | undefined {
    for (const produk of this.data) {
      const varian = produk.varian.find((v) => v.sku === sku);
      if (varian) return { produk, varian };
    }
    return undefined;
  }
}
