import { Controller, Get, Param, Query } from '@nestjs/common';
import { queryProdukSchema, type QueryProduk } from '@toko/contracts';
import { ZodValidationPipe } from '../../../platform/http/zod-validation.pipe.js';
import { KatalogService } from '../application/katalog.service.js';

@Controller('produk')
export class KatalogController {
  constructor(private readonly katalog: KatalogService) {}

  @Get()
  cari(@Query(new ZodValidationPipe(queryProdukSchema)) query: QueryProduk) {
    return this.katalog.cari(query);
  }

  @Get(':sku')
  detail(@Param('sku') sku: string) {
    return this.katalog.detailSku(sku);
  }
}
