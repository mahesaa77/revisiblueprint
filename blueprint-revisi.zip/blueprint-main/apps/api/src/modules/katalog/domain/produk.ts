export interface VarianData {
  sku: string;
  ukuran: string;
  warna: string;
  /** Stok awal untuk seed in-memory; setelah itu stok dikelola modul Inventori. */
  stokAwal: number;
}

export interface ProdukData {
  id: string;
  nama: string;
  kategori: string;
  deskripsi: string;
  harga: number;
  /** Harga pokok per unit (metode rata-rata, disederhanakan sebagai nilai tetap). */
  hpp: number;
  varian: VarianData[];
}

export interface HasilSku {
  produk: ProdukData;
  varian: VarianData;
}

/** Port repository katalog - implementasi Prisma menggantikan in-memory di Fase 1 lanjutan. */
export abstract class ProdukRepository {
  abstract semua(): ProdukData[];
  abstract cariSku(sku: string): HasilSku | undefined;
}
