import { buatSistem } from '../../../../test/sistem.js';

describe('KatalogService', () => {
  it('mencari berdasarkan kata kunci dan kategori', () => {
    const { katalog } = buatSistem();
    const kemeja = katalog.cari({ kategori: 'kemeja', page: 1, pageSize: 12 });
    expect(kemeja.meta.total).toBe(2);
    const batik = katalog.cari({ search: 'batik', page: 1, pageSize: 12 });
    expect(batik.data[0]?.id).toBe('p-batik');
  });

  it('paginasi memotong hasil', () => {
    const { katalog } = buatSistem();
    const h = katalog.cari({ page: 2, pageSize: 4 });
    expect(h.data).toHaveLength(2);
    expect(h.meta.total).toBe(6);
  });

  it('detail via SKU menampilkan stok real-time dan payload QR', () => {
    const { katalog, penjualan } = buatSistem();
    expect(katalog.detailSku('kmj-oxf-pth-m').varianDipilih.stokTersedia).toBe(5);
    return penjualan
      .buat({ idempotencyKey: 'kunci-0001', items: [{ sku: 'KMJ-OXF-PTH-M', qty: 2 }], diskon: 0, pembayaran: [{ metode: 'TUNAI', jumlah: 500000 }] })
      .then(() => {
        const d = katalog.detailSku('KMJ-OXF-PTH-M');
        expect(d.varianDipilih.stokTersedia).toBe(3);
        expect(d.qrPayload).toBe('http://toko.test/produk/KMJ-OXF-PTH-M');
        expect(d.terkait.map((p) => p.id)).toEqual(['p-batik']);
      });
  });

  it('SKU tidak ada -> 404', () => {
    expect(() => buatSistem().katalog.detailSku('XXX-000')).toThrow('tidak ada');
  });
});
