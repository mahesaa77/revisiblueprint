import type { DetailProduk, Produk, QueryProduk } from '@toko/contracts';
import { tidakDitemukan } from '../../../platform/errors.js';
import { InventoriService } from '../../inventori/application/inventori.service.js';
import type { ProdukData, ProdukRepository } from '../domain/produk.js';

export interface HalamanProduk {
  data: Produk[];
  meta: { total: number; page: number; pageSize: number };
}

export class KatalogService {
  constructor(
    private readonly repo: ProdukRepository,
    private readonly inventori: InventoriService,
    private readonly webBaseUrl: string,
  ) {
    // Seed stok awal ke Inventori (hanya untuk SKU yang belum terdaftar).
    for (const p of repo.semua()) for (const v of p.varian) inventori.daftarkan(v.sku, v.stokAwal);
  }

  cari(q: QueryProduk): HalamanProduk {
    const kata = q.search?.toLowerCase();
    const cocok = this.repo.semua().filter((p) => {
      if (q.kategori && p.kategori !== q.kategori.toLowerCase()) return false;
      if (!kata) return true;
      return (
        p.nama.toLowerCase().includes(kata) ||
        p.kategori.includes(kata) ||
        p.varian.some((v) => v.sku.toLowerCase().includes(kata) || v.warna.toLowerCase().includes(kata))
      );
    });
    const mulai = (q.page - 1) * q.pageSize;
    return {
      data: cocok.slice(mulai, mulai + q.pageSize).map((p) => this.keProduk(p)),
      meta: { total: cocok.length, page: q.page, pageSize: q.pageSize },
    };
  }

  /** Detail via scan barcode: SKU menentukan varian yang dipilih; stok real-time dari Inventori. */
  detailSku(sku: string): DetailProduk {
    const hasil = this.repo.cariSku(sku.toUpperCase());
    if (!hasil) throw tidakDitemukan('PRODUK_TIDAK_DITEMUKAN', `Produk dengan SKU ${sku} tidak ada`);
    const produk = this.keProduk(hasil.produk);
    const varianDipilih = produk.varian.find((v) => v.sku === hasil.varian.sku);
    if (!varianDipilih) throw tidakDitemukan('PRODUK_TIDAK_DITEMUKAN', `Varian ${sku} tidak ada`);
    const terkait = this.repo
      .semua()
      .filter((p) => p.kategori === hasil.produk.kategori && p.id !== hasil.produk.id)
      .slice(0, 4)
      .map(({ id, nama, kategori, harga }) => ({ id, nama, kategori, harga }));
    return { produk, varianDipilih, qrPayload: this.qrPayload(varianDipilih.sku), terkait };
  }

  /** Isi QR/barcode per SKU: tautan landing page produk (dapat dibuka juga lewat share link). */
  qrPayload(sku: string): string {
    return `${this.webBaseUrl}/produk/${encodeURIComponent(sku)}`;
  }

  private keProduk(p: ProdukData): Produk {
    return {
      id: p.id, nama: p.nama, kategori: p.kategori, deskripsi: p.deskripsi, harga: p.harga,
      varian: p.varian.map((v) => ({
        sku: v.sku, ukuran: v.ukuran, warna: v.warna, stokTersedia: this.inventori.tersedia(v.sku),
      })),
    };
  }
}
