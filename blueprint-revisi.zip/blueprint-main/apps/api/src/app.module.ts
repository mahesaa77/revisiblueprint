import { Module } from '@nestjs/common';
import { APP_FILTER } from '@nestjs/core';
import { AkuntansiModule } from './modules/akuntansi/akuntansi.module.js';
import { InventoriModule } from './modules/inventori/inventori.module.js';
import { KatalogModule } from './modules/katalog/katalog.module.js';
import { PenjualanModule } from './modules/penjualan/penjualan.module.js';
import { ReservasiModule } from './modules/reservasi/reservasi.module.js';
import { AllExceptionsFilter } from './platform/http/all-exceptions.filter.js';
import { HealthModule } from './platform/health/health.module.js';
import { PlatformModule } from './platform/platform.module.js';

/**
 * Root module. Lima bounded context sesuai blueprint: Katalog (M1), Penjualan/POS (M2),
 * Reservasi (M3), Inventori (M4), Akuntansi (M5). Antar-modul hanya berbicara lewat
 * service yang diekspor atau event di EventBus.
 */
@Module({
  imports: [
    PlatformModule,
    HealthModule,
    InventoriModule,
    KatalogModule,
    PenjualanModule,
    ReservasiModule,
    AkuntansiModule,
  ],
  providers: [{ provide: APP_FILTER, useClass: AllExceptionsFilter }],
})
export class AppModule {}
