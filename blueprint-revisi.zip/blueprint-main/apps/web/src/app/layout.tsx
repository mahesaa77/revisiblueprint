import type { Metadata, Viewport } from 'next';
import Link from 'next/link';
import './globals.css';

export const metadata: Metadata = {
  title: { default: 'Toko Pakaian', template: '%s | Toko Pakaian' },
  description: 'Katalog, kasir, dan reservasi dalam satu platform',
};

export const viewport: Viewport = { width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id">
      <body>
        <header className="site-header">
          <div className="container">
            <Link href="/" className="brand">👕 Toko Pakaian</Link>
            <nav className="nav" aria-label="Navigasi utama">
              <Link href="/">Katalog</Link>
              <Link href="/reservasi">Reservasi</Link>
              <Link href="/kasir">Kasir</Link>
            </nav>
          </div>
        </header>
        <main className="container">{children}</main>
      </body>
    </html>
  );
}
