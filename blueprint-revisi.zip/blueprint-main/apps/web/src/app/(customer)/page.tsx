import Link from 'next/link';
import { StokBadge } from '../../components/stok-badge';
import { ApiError, cariProduk, rupiah, type HalamanProduk } from '../../lib/api';

const KATEGORI = ['kemeja', 'kaos', 'celana', 'jaket', 'rok'];

export default async function KatalogPage({
  searchParams,
}: {
  searchParams: Promise<{ search?: string; kategori?: string }>;
}) {
  const { search, kategori } = await searchParams;
  let hasil: HalamanProduk | null = null;
  let galat: string | null = null;
  try {
    hasil = await cariProduk({ search, kategori });
  } catch (e) {
    galat = e instanceof ApiError ? e.message : 'Terjadi kesalahan tak terduga';
  }

  return (
    <>
      <h1>Katalog Pakaian</h1>
      <p className="muted">Pindai QR di rak atau cari produk di sini. Stok tampil real-time.</p>

      <form className="search" action="/" role="search">
        <label className="sr-only" htmlFor="search">Cari produk</label>
        <input id="search" name="search" defaultValue={search ?? ''} placeholder="Cari nama, warna, atau SKU" />
        {kategori ? <input type="hidden" name="kategori" value={kategori} /> : null}
        <button className="btn" type="submit">Cari</button>
      </form>

      <div className="chips" role="list" aria-label="Filter kategori">
        <Link role="listitem" className="chip" href="/" aria-current={!kategori}>Semua</Link>
        {KATEGORI.map((k) => (
          <Link key={k} role="listitem" className="chip" href={`/?kategori=${k}`} aria-current={kategori === k}>
            {k}
          </Link>
        ))}
      </div>

      {galat ? (
        <p className="alert" role="alert">{galat}. Pastikan API berjalan di port 3000.</p>
      ) : hasil && hasil.data.length === 0 ? (
        <p className="muted">Tidak ada produk yang cocok.</p>
      ) : (
        <ul className="grid" style={{ listStyle: 'none', padding: 0 }}>
          {hasil?.data.map((p) => {
            const total = p.varian.reduce((n, v) => n + v.stokTersedia, 0);
            const pertama = p.varian.find((v) => v.stokTersedia > 0) ?? p.varian[0];
            return (
              <li key={p.id}>
                <Link className="card" href={`/produk/${pertama?.sku ?? ''}`}>
                  <h2>{p.nama}</h2>
                  <p className="price">{rupiah(p.harga)}</p>
                  <p className="muted">{p.varian.length} varian · {p.kategori}</p>
                  <StokBadge stok={total} />
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
