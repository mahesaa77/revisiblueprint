import type { Metadata } from 'next';
import { FormReservasi } from '../../../components/form-reservasi';

export const metadata: Metadata = { title: 'Reservasi' };

export default async function ReservasiPage({
  searchParams,
}: {
  searchParams: Promise<{ sku?: string }>;
}) {
  const { sku } = await searchParams;
  return (
    <>
      <h1>Reservasi &amp; DP</h1>
      <p className="muted">Tahan stok untuk dicoba di fitting room. Besaran DP diatur admin.</p>
      <FormReservasi skuAwal={sku ?? ''} />
    </>
  );
}
