import Link from 'next/link';
import type { Metadata } from 'next';
import { StokBadge } from '../../../../components/stok-badge';
import { ApiError, detailProduk, rupiah } from '../../../../lib/api';

type Props = { params: Promise<{ sku: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { sku } = await params;
  try {
    const d = await detailProduk(sku);
    return { title: d.produk.nama, description: d.produk.deskripsi };
  } catch {
    return { title: 'Produk' };
  }
}

/** Landing page produk (SSR): tujuan dari QR/barcode di rak, juga bisa dibagikan sebagai tautan. */
export default async function DetailPage({ params }: Props) {
  const { sku } = await params;
  try {
    const { produk, varianDipilih, terkait, qrPayload } = await detailProduk(sku);
    return (
      <>
        <p><Link href="/">← Kembali ke katalog</Link></p>
        <div className="detail">
          <div className="placeholder-img" role="img" aria-label={`Foto ${produk.nama}`}>👕</div>
          <div className="stack">
            <h1>{produk.nama}</h1>
            <p className="price" style={{ fontSize: '1.4rem' }}>{rupiah(produk.harga)}</p>
            <p>{produk.deskripsi}</p>

            <section aria-labelledby="varian">
              <h2 id="varian">Pilih varian</h2>
              <ul className="varian-list">
                {produk.varian.map((v) => (
                  <li key={v.sku}>
                    <Link href={`/produk/${v.sku}`} aria-current={v.sku === varianDipilih.sku}>
                      {v.warna} / {v.ukuran}
                      <br />
                      <StokBadge stok={v.stokTersedia} />
                    </Link>
                  </li>
                ))}
              </ul>
            </section>

            <p className="muted">SKU: <code>{varianDipilih.sku}</code></p>
            <div className="row">
              <Link className="btn" href={`/reservasi?sku=${varianDipilih.sku}`} aria-disabled={varianDipilih.stokTersedia === 0}>
                Reservasi untuk dicoba
              </Link>
            </div>
            <p className="muted" style={{ fontSize: '.85rem' }}>Isi QR varian ini: <code>{qrPayload}</code></p>
          </div>
        </div>

        {terkait.length > 0 && (
          <section aria-labelledby="terkait" style={{ marginTop: '2rem' }}>
            <h2 id="terkait">Produk terkait</h2>
            <ul className="grid" style={{ listStyle: 'none', padding: 0 }}>
              {terkait.map((p) => (
                <li key={p.id} className="card">
                  <strong>{p.nama}</strong>
                  <p className="price">{rupiah(p.harga)}</p>
                </li>
              ))}
            </ul>
          </section>
        )}
      </>
    );
  } catch (e) {
    const pesan = e instanceof ApiError ? e.message : 'Terjadi kesalahan tak terduga';
    return (
      <>
        <p className="alert" role="alert">{pesan}</p>
        <p><Link href="/">← Kembali ke katalog</Link></p>
      </>
    );
  }
}
