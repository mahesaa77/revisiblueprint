import type { Metadata } from 'next';
import { Pos } from '../../../components/pos';

export const metadata: Metadata = { title: 'Kasir' };

export default function KasirPage() {
  return (
    <>
      <h1>Kasir (POS)</h1>
      <p className="muted">Scan barcode atau ketik SKU. Transaksi tetap tersimpan bila internet putus.</p>
      <Pos />
    </>
  );
}
