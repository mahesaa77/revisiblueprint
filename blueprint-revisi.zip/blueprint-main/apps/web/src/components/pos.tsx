'use client';

import { useCallback, useEffect, useState, type FormEvent } from 'react';
import type { BuatTransaksi, DetailProduk, MetodeBayar } from '@toko/contracts';
import { ApiError, apiFetch, rupiah } from '../lib/api';

interface BarisKeranjang { sku: string; nama: string; harga: number; qty: number }
interface Struk { id: string; total: number; kembalian: number }

const ANTRIAN_KEY = 'toko.antrian-offline';
const METODE: MetodeBayar[] = ['TUNAI', 'QRIS', 'KARTU', 'EWALLET'];

/**
 * POS sederhana. Bila API tidak terjangkau, transaksi masuk antrian lokal (localStorage)
 * dan dikirim lewat POST /transaksi/batch-sync. IndexedDB (Dexie) + Workbox menyusul di Fase 2.
 */
export function Pos() {
  const [keranjang, setKeranjang] = useState<BarisKeranjang[]>([]);
  const [sku, setSku] = useState('');
  const [diskon, setDiskon] = useState(0);
  const [metode, setMetode] = useState<MetodeBayar>('TUNAI');
  const [bayar, setBayar] = useState(0);
  const [pesan, setPesan] = useState<{ jenis: 'info' | 'galat'; teks: string } | null>(null);
  const [struk, setStruk] = useState<Struk | null>(null);
  const [antrian, setAntrian] = useState<BuatTransaksi[]>([]);

  const simpanAntrian = useCallback((a: BuatTransaksi[]) => {
    setAntrian(a);
    try { localStorage.setItem(ANTRIAN_KEY, JSON.stringify(a)); } catch { /* penyimpanan penuh/diblokir */ }
  }, []);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(ANTRIAN_KEY);
      if (raw) setAntrian(JSON.parse(raw) as BuatTransaksi[]);
    } catch { /* abaikan data rusak */ }
  }, []);

  const subtotal = keranjang.reduce((n, b) => n + b.harga * b.qty, 0);
  const total = Math.max(subtotal - diskon, 0);

  async function tambah(e: FormEvent) {
    e.preventDefault();
    const kode = sku.trim().toUpperCase();
    if (!kode) return;
    try {
      const d = await apiFetch<DetailProduk>(`/produk/${encodeURIComponent(kode)}`);
      const v = d.varianDipilih;
      setKeranjang((k) => {
        const ada = k.find((b) => b.sku === v.sku);
        if (ada) return k.map((b) => (b.sku === v.sku ? { ...b, qty: b.qty + 1 } : b));
        return [...k, { sku: v.sku, nama: `${d.produk.nama} ${v.warna}/${v.ukuran}`, harga: d.produk.harga, qty: 1 }];
      });
      setSku('');
      setPesan(null);
    } catch (err) {
      setPesan({ jenis: 'galat', teks: err instanceof ApiError ? err.message : 'Gagal memuat produk' });
    }
  }

  const ubahQty = (s: string, delta: number) =>
    setKeranjang((k) => k.map((b) => (b.sku === s ? { ...b, qty: b.qty + delta } : b)).filter((b) => b.qty > 0));

  async function bayarSekarang() {
    const payload: BuatTransaksi = {
      idempotencyKey: crypto.randomUUID(),
      items: keranjang.map(({ sku: s, qty }) => ({ sku: s, qty })),
      diskon,
      pembayaran: [{ metode, jumlah: metode === 'TUNAI' ? bayar : total }],
    };
    try {
      const r = await apiFetch<{ transaksi: Struk }>('/transaksi', { method: 'POST', body: JSON.stringify(payload) });
      setStruk(r.transaksi);
      setKeranjang([]); setDiskon(0); setBayar(0);
      setPesan({ jenis: 'info', teks: `Transaksi ${r.transaksi.id} tersimpan` });
    } catch (err) {
      if (err instanceof ApiError && err.status === 0) {
        simpanAntrian([...antrian, payload]);
        setKeranjang([]); setDiskon(0); setBayar(0);
        setPesan({ jenis: 'info', teks: 'Offline: transaksi disimpan di antrian dan akan disinkronkan.' });
      } else {
        setPesan({ jenis: 'galat', teks: err instanceof ApiError ? err.message : 'Gagal menyimpan transaksi' });
      }
    }
  }

  async function sinkron() {
    try {
      const r = await apiFetch<{ hasil: { idempotencyKey: string; status: string }[] }>('/transaksi/batch-sync', {
        method: 'POST', body: JSON.stringify({ transaksi: antrian }),
      });
      const ditolak = new Set(r.hasil.filter((h) => h.status === 'DITOLAK').map((h) => h.idempotencyKey));
      simpanAntrian(antrian.filter((t) => ditolak.has(t.idempotencyKey)));
      setPesan({ jenis: ditolak.size ? 'galat' : 'info', teks: ditolak.size ? `${ditolak.size} transaksi ditolak (mis. stok habis).` : 'Semua transaksi tersinkron.' });
    } catch (err) {
      setPesan({ jenis: 'galat', teks: err instanceof ApiError ? err.message : 'Sinkron gagal' });
    }
  }

  return (
    <div className="pos">
      <section className="card stack" aria-labelledby="keranjang">
        <h2 id="keranjang">Keranjang</h2>
        <form className="search" onSubmit={tambah}>
          <label className="sr-only" htmlFor="sku">SKU atau hasil scan barcode</label>
          <input id="sku" value={sku} onChange={(e) => setSku(e.target.value)} placeholder="Scan / ketik SKU" autoFocus />
          <button className="btn" type="submit">Tambah</button>
        </form>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Item</th><th>Qty</th><th>Subtotal</th></tr></thead>
            <tbody>
              {keranjang.length === 0 && <tr><td colSpan={3} className="muted">Belum ada item.</td></tr>}
              {keranjang.map((b) => (
                <tr key={b.sku}>
                  <td>{b.nama}<br /><span className="muted">{b.sku}</span></td>
                  <td>
                    <button className="btn secondary" aria-label={`Kurangi ${b.nama}`} onClick={() => ubahQty(b.sku, -1)}>−</button>{' '}
                    {b.qty}{' '}
                    <button className="btn secondary" aria-label={`Tambah ${b.nama}`} onClick={() => ubahQty(b.sku, 1)}>+</button>
                  </td>
                  <td>{rupiah(b.harga * b.qty)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="card stack" aria-labelledby="pembayaran">
        <h2 id="pembayaran">Pembayaran</h2>
        <label className="stack">Diskon (Rp)
          <input type="number" min={0} value={diskon} onChange={(e) => setDiskon(Math.max(0, Number(e.target.value)))} />
        </label>
        <label className="stack">Metode
          <select value={metode} onChange={(e) => setMetode(e.target.value as MetodeBayar)}>
            {METODE.map((m) => <option key={m}>{m}</option>)}
          </select>
        </label>
        {metode === 'TUNAI' && (
          <label className="stack">Uang diterima (Rp)
            <input type="number" min={0} value={bayar} onChange={(e) => setBayar(Number(e.target.value))} />
          </label>
        )}
        <p className="row"><span>Total</span><strong className="price">{rupiah(total)}</strong></p>
        {metode === 'TUNAI' && bayar >= total && total > 0 && <p className="muted">Kembalian {rupiah(bayar - total)}</p>}
        <button className="btn" disabled={keranjang.length === 0 || (metode === 'TUNAI' && bayar < total)} onClick={() => void bayarSekarang()}>
          Bayar
        </button>

        {pesan && <p className={pesan.jenis === 'galat' ? 'alert' : 'alert info'} role="status">{pesan.teks}</p>}
        {struk && <p className="muted">Struk terakhir: {struk.id} · {rupiah(struk.total)}</p>}
        {antrian.length > 0 && (
          <div className="row">
            <span className="badge warn">{antrian.length} transaksi menunggu sinkron</span>
            <button className="btn secondary" onClick={() => void sinkron()}>Sinkronkan</button>
          </div>
        )}
      </section>
    </div>
  );
}
