export function StokBadge({ stok }: { stok: number }) {
  if (stok === 0) return <span className="badge out">Habis</span>;
  if (stok <= 3) return <span className="badge warn">Tersisa {stok}</span>;
  return <span className="badge ok">Stok {stok}</span>;
}
