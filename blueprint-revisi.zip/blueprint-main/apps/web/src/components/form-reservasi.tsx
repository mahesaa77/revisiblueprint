'use client';

import { useState, type FormEvent } from 'react';
import { ApiError, apiFetch, rupiah } from '../lib/api';

interface Reservasi {
  id: string;
  sku: string;
  qty: number;
  total: number;
  dp: number;
  sisa: number;
  status: string;
  batasWaktu: string;
}

export function FormReservasi({ skuAwal }: { skuAwal: string }) {
  const [reservasi, setReservasi] = useState<Reservasi | null>(null);
  const [galat, setGalat] = useState<string | null>(null);
  const [sibuk, setSibuk] = useState(false);

  async function jalankan(aksi: () => Promise<Reservasi>) {
    setSibuk(true);
    setGalat(null);
    try {
      setReservasi(await aksi());
    } catch (e) {
      setGalat(e instanceof ApiError ? e.message : 'Terjadi kesalahan tak terduga');
    } finally {
      setSibuk(false);
    }
  }

  function kirim(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    void jalankan(() =>
      apiFetch<Reservasi>('/reservasi', {
        method: 'POST',
        body: JSON.stringify({
          sku: String(f.get('sku')).trim().toUpperCase(),
          qty: Number(f.get('qty')),
          namaPelanggan: String(f.get('nama')),
          kontak: String(f.get('kontak')),
        }),
      }),
    );
  }

  const aksi = (jalur: 'bayar-dp' | 'lunasi') => () =>
    void jalankan(() => apiFetch<Reservasi>(`/reservasi/${reservasi?.id}/${jalur}`, { method: 'POST' }));

  return (
    <div className="stack" style={{ maxWidth: 520 }}>
      {galat && <p className="alert" role="alert">{galat}</p>}

      {!reservasi ? (
        <form className="stack card" onSubmit={kirim}>
          <label className="stack">SKU produk
            <input name="sku" defaultValue={skuAwal} required minLength={3} placeholder="mis. KMJ-OXF-BIR-M" />
          </label>
          <label className="stack">Jumlah
            <input name="qty" type="number" min={1} defaultValue={1} required />
          </label>
          <label className="stack">Nama
            <input name="nama" required minLength={2} autoComplete="name" />
          </label>
          <label className="stack">Kontak (WhatsApp)
            <input name="kontak" required minLength={5} inputMode="tel" autoComplete="tel" />
          </label>
          <button className="btn" disabled={sibuk}>{sibuk ? 'Memproses…' : 'Buat reservasi'}</button>
        </form>
      ) : (
        <section className="card stack" aria-live="polite">
          <h2>Reservasi {reservasi.id}</h2>
          <p>Status: <strong>{reservasi.status.replaceAll('_', ' ')}</strong></p>
          <p>Total {rupiah(reservasi.total)} · DP {rupiah(reservasi.dp)} · Sisa {rupiah(reservasi.sisa)}</p>
          <p className="muted">Stok ditahan sampai {new Date(reservasi.batasWaktu).toLocaleString('id-ID')}</p>
          <div className="row">
            <button className="btn" disabled={sibuk || reservasi.status !== 'MENUNGGU_DP'} onClick={aksi('bayar-dp')}>
              Bayar DP (simulasi)
            </button>
            <button className="btn secondary" disabled={sibuk || reservasi.status !== 'DP_DIBAYAR'} onClick={aksi('lunasi')}>
              Lunasi
            </button>
          </div>
          <p className="muted" style={{ fontSize: '.85rem' }}>
            Pembayaran memakai adapter fake (PAYMENT_DRIVER=fake); Midtrans sandbox menyusul di Fase 2.
          </p>
        </section>
      )}
    </div>
  );
}
