import type { DetailProduk, ErrorResponse, Produk } from '@toko/contracts';

/** Server component memakai URL internal (mis. di Docker); browser memakai URL publik. */
const BASE_PUBLIK = process.env['NEXT_PUBLIC_API_BASE_URL'] ?? 'http://localhost:3000/api/v1';
const BASE_SERVER = process.env['API_INTERNAL_URL'] ?? BASE_PUBLIK;

export const apiBase = (): string => (typeof window === 'undefined' ? BASE_SERVER : BASE_PUBLIK);

export interface HalamanProduk {
  data: Produk[];
  meta: { total: number; page: number; pageSize: number };
}

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
  ) {
    super(message);
  }
}

export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${apiBase()}${path}`, {
      cache: 'no-store',
      ...init,
      headers: { 'Content-Type': 'application/json', ...init?.headers },
    });
  } catch {
    throw new ApiError(0, 'JARINGAN', 'Tidak dapat menghubungi server API');
  }
  const body: unknown = await res.json().catch(() => null);
  if (!res.ok) {
    const e = body as Partial<ErrorResponse> | null;
    throw new ApiError(res.status, e?.code ?? 'HTTP_ERROR', e?.message ?? `Permintaan gagal (${res.status})`);
  }
  return body as T;
}

export const cariProduk = (params: { search?: string; kategori?: string }) => {
  const q = new URLSearchParams();
  if (params.search) q.set('search', params.search);
  if (params.kategori) q.set('kategori', params.kategori);
  return apiFetch<HalamanProduk>(`/produk?${q.toString()}`);
};

export const detailProduk = (sku: string) =>
  apiFetch<DetailProduk>(`/produk/${encodeURIComponent(sku)}`);

export const rupiah = (n: number): string =>
  new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(n);
