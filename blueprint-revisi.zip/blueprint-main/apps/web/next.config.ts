import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  output: 'standalone',
  // Mengizinkan import langsung dari source workspace.
  transpilePackages: ['@toko/contracts'],
};

export default nextConfig;
